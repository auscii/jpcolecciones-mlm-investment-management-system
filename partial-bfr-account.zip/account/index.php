<!-- ||||||||||||||||          AUTHOR: Walter A. Narvasa           |||||||||||||||| -->
<!-- |||||||||||||||| All rights reserved, Copyright (c) 2020-2021 |||||||||||||||| -->
<!-- |||||||||||||||| THIS IS NOT YOUR CODE!  ACCESS DENIED!!!!    |||||||||||||||| -->
<!--

                                .,od88888888888bo,.
                            .d88888888888888888888888b.
                         .d88888888888888888888888888888b.
                       .d888888888888888888888888888888888b.
                     .d8888888888888888888888888888888888888b.
                    d88888888888888888888888888888888888888888b
                   d8888888888888888888888888888888888888888888b
                  d888888888888888888888888888888888888888888888
                  8888888888888888888888888888888888888888888888
                  8888888888888888888888888888888888888888888888
                  8888888888888888888888888888888888888888888888
                  Y88888888888888888888888888888888888888888888P
                  "8888888888P'   "Y8888888888P"    "Y888888888"
                   88888888P        Y88888888P        Y88888888
                   Y8888888          ]888888P          8888888P
                    Y888888          d888888b          888888P
                     Y88888b        d88888888b        d88888P
                      Y888888b.   .d88888888888b.   .d888888
                       Y8888888888888888P Y8888888888888888
                        888888888888888P   Y88888888888888
                        "8888888888888[     ]888888888888"
                           "Y888888888888888888888888P"
                                "Y88888888888888P"
                             888b  Y8888888888P  d888
                             "888b              d888"
                              Y888bo.        .od888P
                               Y888888888888888888P
                                "Y88888888888888P"
                                  "Y8888888888P"
          d8888bo.                  "Y888888P"                  .od888b
         888888888bo.                  """"                  .od8888888
         "88888888888b.                                   .od888888888[
         d8888888888888bo.                              .od888888888888
       d88888888888888888888bo.                     .od8888888888888888b
       ]888888888888888888888888bo.            .od8888888888888888888888b=
       888888888P" "Y888888888888888bo.     .od88888888888888P" "Y888888P=
        Y8888P"           "Y888888888888bd888888888888P"            "Y8P
          ""                   "Y8888888888888888P"
                                 .od8888888888bo.
                             .od888888888888888888bo.
                         .od8888888888P"  "Y8888888888bo.
                      .od8888888888P"        "Y8888888888bo.
                  .od88888888888P"              "Y88888888888bo.
        .od888888888888888888P"                    "Y8888888888888888bo.
       Y8888888888888888888P"                         "Y8888888888888888b=
       888888888888888888P"                            "Y8888888888888888=
        "Y888888888888888                               "Y88888888888888P=
             ""Y8888888P                                  "Y888888P"
                "Y8888P                                     Y888P"
                   ""                                        """
-->

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>JP Colecciones | Investment MLM System</title>
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="author" content="Walter Aquino Narvasa">  
<link rel="shortcut icon" href="images/favicon.png">
<script language=JavaScript>m='%3C%21--%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%20%20%20%20Copyright%20%A9%201999-2002%204n0nym0u5%20-%20All%20Rights%20Reserved%20%20%20%20%20%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20THIS%20COPYRIGHT%20INFORMATION%20MUST%20REMAIN%20INTACT%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20AND%20MAY%20NOT%20BE%20MODIFIED%20IN%20ANY%20WAY%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%20%23%0D%0A%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%23%0D%0A%23%0D%0A%23%20When%20you%20downloaded%20this%20script%20you%20agreed%20to%20accept%20the%20terms%20%0D%0A%23%20of%20this%20Agreement.%20This%20Agreement%20is%20a%20legal%20contract%2C%20which%20%0D%0A%23%20specifies%20the%20terms%20of%20the%20license%20and%20warranty%20limitation%20between%20%0D%0A%23%20you%20and%204n0nym0u5.%20You%20should%20carefully%20read%20the%20following%20%0D%0A%23%20terms%20and%20conditions%20before%20installing%20or%20using%20this%20software.%20%20%0D%0A%23%20Unless%20you%20have%20a%20different%20license%20agreement%20obtained%20from%20%0D%0A%23%204n0nym0u5%2C%20installation%20or%20use%20of%20this%20software%20indicates%20%0D%0A%23%20your%20acceptance%20of%20the%20license%20and%20warranty%20limitation%20terms%0D%0A%23%20contained%20in%20this%20Agreement.%20If%20you%20do%20not%20agree%20to%20the%20terms%20of%20this%0D%0A%23%20Agreement%2C%20promptly%20delete%20and%20destroy%20all%20copies%20of%20the%20Software.%0D%0A%23%0D%0A%23%20Versions%20of%20the%20Software%20%0D%0A%23%20Only%20one%20copy%20of%20the%20registered%20version%20of%204n0nym0u5%20%0D%0A%23%20may%20used%20on%20one%20web%20site.%0D%0A%23%20%0D%0A%23%20License%20to%20Redistribute%0D%0A%23%20Distributing%20the%20software%20and/or%20documentation%20with%20other%20products%0D%0A%23%20%28commercial%20or%20otherwise%29%20or%20by%20other%20than%20electronic%20means%20without%0D%0A%23%204n0nym0u5%27s%20prior%20written%20permission%20is%20forbidden.%0D%0A%23%20All%20rights%20to%20the%204n0nym0u5%20software%20and%20documentation%20not%20expressly%0D%0A%23%20granted%20under%20this%20Agreement%20are%20reserved%20to%20an0nym0us.%0D%0A%23%0D%0A--%3E%3Cscript%20language%3D%22JavaScript%22%20src%3D%220010010000010010000.js%22%3E%3C/script%3E%3C%21--%0D%0A%23%20Disclaimer%20of%20Warranty%0D%0A%23%20THIS%20SOFTWARE%20AND%20ACCOMPANYING%20DOCUMENTATION%20ARE%20PROVIDED%20%22AS%20IS%22%20AND%0D%0A%23%20WITHOUT%20WARRANTIES%20AS%20TO%20PERFORMANCE%20OF%20MERCHANTABILITY%20OR%20ANY%20OTHER%0D%0A%23%20WARRANTIES%20WHETHER%20EXPRESSED%20OR%20IMPLIED.%20%20%20BECAUSE%20OF%20THE%20VARIOUS%20HARDWARE%0D%0A%23%20AND%20SOFTWARE%20ENVIRONMENTS%20INTO%20WHICH%20an0nym0us%20MAY%20BE%20USED%2C%20NO%20WARRANTY%20%0D%0A%23%20OF%20FITNESS%20FOR%20A%20PARTICULAR%20PURPOSE%20IS%20OFFERED.%20%20THE%20USER%20MUST%20ASSUME%20THE%0D%0A%23%20ENTIRE%20RISK%20OF%20USING%20THIS%20PROGRAM.%20%20ANY%20LIABILITY%20OF%20an0nym0us%20WILL%20BE%0D%0A%23%20LIMITED%20EXCLUSIVELY%20TO%20PRODUCT%20REPLACEMENT%20OR%20REFUND%20OF%20PURCHASE%20PRICE.%0D%0A%23%20IN%20NO%20CASE%20SHALL%20an0nym0us%20BE%20LIABLE%20FOR%20ANY%20INCIDENTAL%2C%20SPECIAL%20OR%0D%0A%23%20CONSEQUENTIAL%20DAMAGES%20OR%20LOSS%2C%20INCLUDING%2C%20WITHOUT%20LIMITATION%2C%20LOST%20PROFITS%0D%0A%23%20OR%20THE%20INABILITY%20TO%20USE%20EQUIPMENT%20OR%20ACCESS%20DATA%2C%20WHETHER%20SUCH%20DAMAGES%20ARE%0D%0A%23%20BASED%20UPON%20A%20BREACH%20OF%20EXPRESS%20OR%20IMPLIED%20WARRANTIES%2C%20BREACH%20OF%20CONTRACT%2C%0D%0A%23%20NEGLIGENCE%2C%20STRICT%20TORT%2C%20OR%20ANY%20OTHER%20LEGAL%20THEORY.%20THIS%20IS%20TRUE%20EVEN%20IF%0D%0A%23%20an0nym0us%20IS%20ADVISED%20OF%20THE%20POSSIBILITY%20OF%20SUCH%20DAMAGES.%20IN%20NO%20CASE%20WILL%0D%0A%23%20an0nym0us%27%20LIABILITY%20EXCEED%20THE%20AMOUNT%20OF%20THE%20LICENSE%20FEE%20ACTUALLY%20PAID%0D%0A%23%20BY%20LICENSEE%20TO%20an0nym0us.--%3E';d=unescape(m);document.write(d);</script>

<!-- |||||||||||||||| THIS IS NOT YOUR CODE!  ACCESS DENIED!!!!  |||||||||||||||| -->