
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>izi69 | Investment MLM System<</title>
</head>
<body>
  <script src="js/libs/jquery-1.8.2.min.js"></script>
<script>
  alert("start!");
  VerifySponsorID();

  function VerifySponsorID() {
    alert("begin!");
    // $(document).ready(function(){
    //     var url_connect = 'http://localhost/ebrgy/authentication/d4t43ntry4dd0n.php?key=1414&type=2' ;
    //     $.ajax({
    //       url: url_connect,
    //       dataType: 'jsonp',
    //       jsonp: 'ebrgyjs0n_0011010100010010111',
    //       timeout: 5000,
    //       success: function(data, status){
    //         if (data.length == 0) {
    //           alert("no record");
    //         } 
    //         $.each(data, function(i,item){ 
    //           if (item.eb_govtprogram==undefined){
    //           } else {
    //             alert(item.eb_govtprogram);
    //           }
    //         });
    //       },
    //       error: function(){              
    //       } }); 
    //   });  

      
      
  }


</script>
</body>
</html>
