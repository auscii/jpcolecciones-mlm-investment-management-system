<!-- ||||||||||||||||          AUTHOR: Walter A. Narvasa 		   |||||||||||||||| -->
<!-- |||||||||||||||| All rights reserved, Copyright (c) 2021-2022 |||||||||||||||| -->
<!-- ||||||||||||||||	THIS IS NOT YOUR CODE!  ACCESS DENIED!!!!  |||||||||||||||| -->

document.write('<title>JP Colecciones | Investment MLM System</title>');
document.write('<frameset rows="100%,*" framespacing="0" border="0">');
document.write('<frame frameborder="0" name="topFrame" src="00100000100100login.php" noresize="noresize" />');
document.write('</frameset>');

<!-- ||||||||||||||||	THIS IS NOT YOUR CODE!  ACCESS DENIED!!!!  |||||||||||||||| -->