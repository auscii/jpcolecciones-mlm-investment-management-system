<?php
if (isset($_GET["izi69_city"])) {
	$izi69_city = $_GET['izi69_city'];	
} else {
	$izi69_city = "wala";
}

echo $izi69_city ;
?>
